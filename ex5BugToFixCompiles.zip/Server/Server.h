/*
 * Server.h
 *
 *  Created on: Dec 2, 2017
 *      Author: Ofir Ben Shoham.
 */

#ifndef SERVER_H_
#define SERVER_H_

#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <iostream>
#include <string.h>
#include "GameManager.h"
#include <stdio.h>
#include "CommandsManager.h"
#include <vector>


namespace std {

class Server {
public:

	/**
	 * constructor of the server. Gets:
	 * const char* ipNum - the ip adress of the server.
	 * int portNum - the numebr of the port.
	 * Both helps us to make a connection.
	 */
	Server(int portNum, GameManager* gm);

	/**
	 * return true if we can continue to ask from the clients for inputs.
	 * Until the game is ended or ("END" was sent).
	 */
	bool checkIfcanContinue();

	/**
	 * Ask for input from the client, interprets him and send the result
	 * (the printed board after the change), to the other client.
	 * Then, continue with that process for the other client.
	 *
	 * int clientSocToRead - the socket number of the client that we read the cell from.
	 * int clientSocToWrite - the socket number of the client that we will pass the cell to.
	 *
	 * Important: in the assignment page, it's written that we get assume that the
	 * input is legal - It means: no needed to check the input from the clients.
	 */
	void handleWithInput(int clientSocToRead, int clientSocToWrite);

	/**
	 * Initialize the socket of the server and checks that it's valid.
	 */
	void socketInitialize();

	/**
	 * start the server and set him.
	 */
	void setAndStartServer();

	/**
	 * define client sockets by accepting them.
	 */
	void defineClientsSockets();

	/**
	 * accept the first & second client into the server and return his socket number.
	 */
	int acceptFirstClientSocket();
	int acceptSecondClientSocket();

	/**
	 * This method starting the game with the clients.
	 * gets GameDescriptor des- contian data about the first & second clients sockets. And name of game.
	 */
	 void* workWithClients(void* des);

	/**
	 * close the socket of the server.
	 */
	void closeServer();

	/**
	 * read x,y from clientSocToGetFrom
	 * write x,y to clientSocToSend.
	 */
	void GetAndSendIntsToClient(int clientSocToGetFrom, int clientSocToSend);

	/**
	 * int clientSocToWriteInto - to which client socket to write.
	 * write the turn in cell (row, col).
	 */
	void sendTurn(int clientSocToWriteInto, int row, int col);



	/**
	 * return pointer to gameManager.
	 */
	GameManager* getGamesManager() {return gamesManager;}

	/**
	 * start a new game
	 */
	void startGameByGameDescriptor(string name, int firstClientSock, int secondClientSock);

	/**
	 * the function waits to read a command from the sending Client and it operates the right function accordingly by command manager
	 * sendingClientSock is the socket of the client who we want to receive the command from
	 * receivingClientSock is an optional argument, in case we need expect to operate a function that needs the receiving client sock as well
	 */
	void readAndRunCommand(int sendingClientSock, int receivingClientSock = 0);

private:
	// the files of the server are ip adress & port number.
	int serverSocket;
	int serverPortNumber;
	GameManager* gamesManager;
	CommandsManager commandsManager;
	bool canContinue;

	vector<string> getArgs(string command);
	string getCommand(string command);

};

} /* namespace std */

#endif /* SERVER_H_ */
