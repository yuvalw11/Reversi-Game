/*
 * Task.h
 *
 *  Created on: Jan 18, 2018
 *      Author: ofir
 */

#ifndef TASK_H_
#define TASK_H_

#include <map>
#include <string>
#include "command.h"

class Task {
public:
	Task(void * (*func)(void *arg), void* arg) :
			func(func), arg(arg) {
	}
	void execute() {
		func(arg);
	}
	virtual ~Task() {
		struct argsToExcuteCommand* dataForExcuteCommand = (argsToExcuteCommand*) this->arg;
		/*delete dataForExcuteCommand->commandsMap["start"];
		delete dataForExcuteCommand->commandsMap["list_games"];
		delete dataForExcuteCommand->commandsMap["join"];
		delete dataForExcuteCommand->commandsMap["play"];
		delete dataForExcuteCommand->commandsMap["close"];
		delete dataForExcuteCommand->commandsMap;*/
		delete dataForExcuteCommand;
	}
private:
	void * (*func)(void *arg);
	void *arg;
};

#endif /* TASK_H_ */
