/*
 * ThreadServer.cpp
 *
 *  Created on: Dec 28, 2017
 *      Author: Ofir Ben-Shoham.
 */

#include "ThreadServer.h"
#include "StructDef.h"
#include "Server.h"
#include "ThreadStarter.h"

ThreadServer::ThreadServer(Server* server) {
	this->shouldContinue = new bool();
	*this->shouldContinue = true;
	this->server = server;
}

void* ThreadServer::gamesRunner(void* input) {

	cout << "print here\n";
	struct argsToThreadServer *gameDes = (struct argsToThreadServer *) input;
	struct argsToThreadServer gameDescription; //gameDescription to save

	gameDescription.firstClientSocket = gameDes->firstClientSocket;
	gameDescription.secondClientSocket = gameDes->secondClientSocket;
	gameDescription.gameManager = gameDes->gameManager;
	gameDescription.serverSocket = gameDes->serverSocket;
	gameDescription.shouldContinue = gameDes->shouldContinue;
	delete gameDes; //free the memory allocated

	// cin to get an input from the server.
	// Because we want the abillity to close all the games & the server using command "end" from the server main runner.
	string gettingInput;

	while (true) {
		cin >> gettingInput;
		if (gettingInput.compare("exit") == 0) {
			cout
					<< "I got exit from the user. Prepering to close all the games & sockets\n";
			break; // exit from the thread, and return to the main to close all the needed things.
		}
	}

	*gameDescription.shouldContinue = false;

}

void ThreadServer::runServerLoop() {
	struct passedArguments {
		int firstClientSocket;
		int secondClientSocket;
		GameManager* gameManager;
	};

	struct passedArguments argsToPass;
	argsToPass.gameManager = this->server->getGamesManager();

	//expecting new connections all the time
	while (*this->shouldContinue == true) {
		argsToPass.firstClientSocket = server->acceptClientSocket(
				server->getServerSocket());
		argsToPass.secondClientSocket = -1; // by default, because we didn't do accept to the second client.
		ThreadStarter::readAndRunCommand((void*) &argsToPass); // pass the struct with the data.
	}
}

void ThreadServer::exitFromAllTheGames() {
	// first, pass on the games
	GameManager* gameMng = this->server->getGamesManager();
	vector<GameDescriptor*> gamesToRemove = gameMng->getGamesDesList();
	unsigned int index = 0;
	for (index = 0; index < gamesToRemove.size(); index++) {
		// remove each game
		GameDescriptor* d = gamesToRemove[index];
		string currentGameName = d->getNameOfGame();

		// because if the clients gets (-100, -100) he knows that he needs to finish the game, and close his socket.
		write(d->getFirstClientSocket(), "-100", sizeof("-100")); // send -100 to the socket of the first client
		write(d->getFirstClientSocket(), "-100", sizeof("-100")); // send -100 to the socket of the first client
		write(d->getSecondClientSocket(), "-100", sizeof("-100")); // the same for the second client.
		write(d->getSecondClientSocket(), "-100", sizeof("-100")); // the same for the second client.

		// close the thread of the game and remove it from the vector<GameDescriptor>:
		gameMng->removeGame(currentGameName);

		// the socket are closed into the games itself, since they get -100 as an input cell.
		// now, after closing the clients sockets we want to close the thread of this game
	}

}

bool* ThreadServer::getPointerToShouldContinue() {
	return this->shouldContinue;
}
