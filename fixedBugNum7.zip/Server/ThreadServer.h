/*
 * ThreadServer.h
 *
 *  Created on: Dec 28, 2017
 *      Author: Ofir Ben-Shoham.
 */

#ifndef THREADSERVER_H_
#define THREADSERVER_H_
#include "Server.h"
#include "GameManager.h"

namespace std {

class ThreadServer {
public:
	ThreadServer(Server* server);
	static void* gamesRunner(void* input);
	void runServerLoop();
	static void exitFromAllTheGames(GameManager* gameMng, Server* server);
	bool* getPointerToShouldContinue();
private:
	bool* shouldContinue;
	Server* server;
};

} /* namespace std */

#endif /* THREADSERVER_H_ */
