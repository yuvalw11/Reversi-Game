/*
 * Main.cpp
 *
 *  Created on: Dec 2, 2017
 *     Names : Yuval Weinstein & Ofir Ben Shoham.
 *     Id: 208580613 & 208642496.
 */
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>
#include "Server.h"
#include "ListGamesFunc.h"
#include "StartGameFunc.h"

using namespace std;

int main() {
	cout << "hi";

	/*int portNumber;
	string line;
	ifstream myfile("exe/ConnectingDetails.txt");

	if (!myfile.is_open()) {
		cout << "Unable to open file";
		return -1;
	}
	// Otherwise, opened the file.

	getline(myfile, line); // no use of the ip adress in the server.

	getline(myfile, line);
	size_t posPort = line.find(":") + 1;
	if (posPort > 0) {
		string temp = line.substr(posPort);
		portNumber = atoi(temp.c_str());
	}
	myfile.close();

	Server server(portNumber, NULL); // the port we read from the file.
	server.socketInitialize();
	server.setAndStartServer();
	int firstClientSocket = server.acceptFirstClientSocket();
	int secondClientSocket = server.acceptSecondClientSokcet();
	server.workWithClients(firstClientSocket,secondClientSocket);*/

	/*GameManager gm;
	gm.addGame("newName", 2, 2);

	Server server(89888, &gm);

	StartGameFunc sgf(&server);
	vector<string> toPass; toPass.push_back("2"); toPass.push_back("newName");
	sgf.execute(toPass);*/


	return 0;
}

