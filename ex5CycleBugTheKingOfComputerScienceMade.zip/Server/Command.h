/*
 * Command.h
 *
 *  Created on: Dec 22, 2017
 *      Author: Ofir Ben-Shoham.
 */

#ifndef COMMAND_H_
#define COMMAND_H_

#include <vector>
#include <string>
#include "Server.h"
#include <stdlib.h>

using namespace std;
class Command {

public:
 virtual void execute(vector<string> args, Server* server) = 0; // to be implemente in the derived classes.
 virtual ~Command() {}


private:
 /**
  * define in the base class the server as a field, in order to avoid
  * duplicate it in all the derived classes.
  */
};



#endif /* COMMAND_H_ */
