/*
 * Main.cpp
 *
 *  Created on: Dec 2, 2017
 *      Author: Ofir Ben Shoham
 */
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>
#include "Client.h"

using namespace std;

int main() {

	Client firstClient("127.0.0.1", 63721);
	try {
		firstClient.connectToServer();
	} catch (const char *msg) {
		cout << "Failed to connect to server. Reason:" << msg << endl;
		exit(-1);
	}

	cout << "one/two are connected\n";

	// read his player number id
	firstClient.readHisCilentNum();
	cout << "Important: playerNum is: " << firstClient.getPlayerNum()<<endl;

	// check if need to remove this line:
	//firstClient.sendToServer(true); // just once in the first time

	while (true) {

		try {
			//firstClient.sendToServer();
			firstClient.sendToServer();
			cout <<"passed the writing\n";

		} catch (const char *msg) {
			cout << "Failed to send exercise to server. Reason is: " << msg
					<< endl;
		}
	}

	return 0;
}

