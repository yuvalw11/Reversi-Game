/*
 * Client.h
 *
 *  Created on: Dec 6, 2017
 *      Author: ofir
 */

#ifndef CLIENT_H_
#define CLIENT_H_
#include "Cell.h"


namespace std {

class Client {
public:
	Client(const char *serverIP, int serverPort);
	void connectToServer(int isSecond = 0);
	void sendToServer(bool isFirstTime = false);
	void readHisCilentNum();
	Cell getCurrentTurn();
	void sendTurnToServer(int row, int col);

	int getPlayerNum() const {
		return playerNum;
	}

private:
	const char *serverIP;
	int serverPort;
	int clientSocket;
	int playerNum;

}; /* namespace std */
}

#endif /* CLIENT_H_ */
