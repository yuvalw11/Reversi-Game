/*
 * RemotePlayer.h
 *
 *  Created on: Dec 8, 2017
 *      Author: ofir
 */

#ifndef REMOTEPLAYER_H_
#define REMOTEPLAYER_H_
#include "Client.h"
#include "temp/GameRunner.h"

namespace std {

class RemotePlayer : public Player {
public:
	RemotePlayer(Client myClient, GameLogic gl, bool isFirstPlayer = false);
	Cell chooseCell(Board* board, char playerSign);
	void printPossibleMoves(Board &board, char playerSign);
	//RemotePlayer(){}
private:
	GameLogic gameLogic;
	Client client;
	char currentPlayer;
};

} /* namespace std */

#endif /* REMOTEPLAYER_H_ */
