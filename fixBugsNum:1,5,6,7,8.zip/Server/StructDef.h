/*
 * StructDef.h
 *
 *  Created on: Dec 28, 2017
 *      Author: ofir
 */

#ifndef STRUCTDEF_H_
#define STRUCTDEF_H_
#include "GameManager.h"
#include "Server.h"

// define the struct that will be sent as void*
struct passedArguments {
	int firstClientSocket;
	int secondClientSocket;
	GameManager* gameManager;
};

struct argsToThreadServer {
	int firstClientSocket;
	int secondClientSocket;
	int serverSocket;
	Server* server;
	GameManager* gameManager;
	bool* shouldContinue;
};


#endif /* STRUCTDEF_H_ */
