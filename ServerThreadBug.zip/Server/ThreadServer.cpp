/*
 * ThreadServer.cpp
 *
 *  Created on: Dec 28, 2017
 *      Author: Ofir Ben-Shoham.
 */

#include "ThreadServer.h"
#include "StructDef.h"
#include "Server.h"
#include "ThreadStarter.h"

void* ThreadServer::gamesRunner(void* input) {

	/* Should enter to this function, but it didn't.
	 As you see, it doesn't write "print here" */

	cout << "print here\n";
	struct argsToThreadServer *gameDes = (struct argsToThreadServer *) input;
	struct argsToThreadServer gameDescription; //gameDescription to save

	gameDescription.firstClientSocket = gameDes->firstClientSocket;
	gameDescription.secondClientSocket = gameDes->secondClientSocket;
	gameDescription.gameManager = gameDes->gameManager;
	gameDescription.serverSocket = gameDes->serverSocket;
	delete gameDes; //free the memory allocated

	// cin to get an input from the server.
	// Because we want the abillity to close all the games & the server using command "end" from the server main runner.
	string gettingInput = " ";

	while (true) {
		cin >> gettingInput;
		if (gettingInput.compare("exit") == 0) {
			cout
					<< "I got exit from the user. Prepering to close all the games & sockets\n";
			break; // exit from the thread, and return to the main to close all the needed things.
		}
		cout << "try to do accept\n";
		gameDescription.firstClientSocket = Server::acceptClientSocket(
				gameDescription.serverSocket);
		cout << "accept was done, client socket is:"
				<< gameDescription.firstClientSocket << endl;
		gameDescription.secondClientSocket = -1; // by defualt, because we didn't do accept to the second client.
		struct passedArguments* argsToPass = new struct passedArguments();
		argsToPass->firstClientSocket = gameDescription.firstClientSocket;
		argsToPass->secondClientSocket = gameDescription.secondClientSocket;
		argsToPass->gameManager = gameDescription.gameManager;

		ThreadStarter::readAndRunCommand((void*) argsToPass); // pass the struct with the data.
		delete argsToPass;
	}
}
