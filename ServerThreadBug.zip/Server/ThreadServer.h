/*
 * ThreadServer.h
 *
 *  Created on: Dec 28, 2017
 *      Author: Ofir Ben-Shoham.
 */

#ifndef THREADSERVER_H_
#define THREADSERVER_H_

namespace std {

class ThreadServer {
public:
	static void* gamesRunner(void* input);
};

} /* namespace std */

#endif /* THREADSERVER_H_ */
